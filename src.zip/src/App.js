import './App.css';

import CommonTreeContainer from "./components/CommonTreeContainer";

function App() {
  return (
    <div >
      <CommonTreeContainer></CommonTreeContainer>
    </div>
  );
}

export default App;
